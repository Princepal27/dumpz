<?php
echo get_template_part('front-page');
 ?>